<?php
    require_once "header.php";
?>
<html>
    <div class="container">

    </div>
</html>
<?php
require_once "footer.php";
?>