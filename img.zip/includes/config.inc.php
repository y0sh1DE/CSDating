<?php
    $GLOBALS['SESSION_LIFETIME'] = 60;
    $GLOBALS['ADMIN_UNAME'] = "Yoshi";